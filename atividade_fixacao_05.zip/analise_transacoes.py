"""
Atividade de Fixação 05 - Aplicação para análise de dados (Fintech)

Pipeline: ingestão -> limpeza -> engenharia temporal -> filtros bitwise ->
cruzamento/agregação -> detecção de outliers (Z-Score) -> visualização.
"""
import pandas as pd
import numpy as np
import matplotlib

matplotlib.use("Agg")  # permite rodar sem interface gráfica
import matplotlib.pyplot as plt

ARQUIVO_TRANSACOES = "transacoes.csv"
FUSO = "America/Sao_Paulo"

RISCO_DICT = {
    "C100": "Baixo",
    "C101": "Alto",
    "C102": "Médio",
    "C103": "Baixo",
    "C104": "Alto",
}


# ---------------------------------------------------------------------------
# 1. Ingestão, performance e limpeza
# ---------------------------------------------------------------------------
def carregar_e_limpar(caminho: str) -> pd.DataFrame:
    df = pd.read_csv(
        caminho,
        encoding="latin1",  # encoding legado
        dtype={
            "id_cliente": "category",   # menos memória
            "origem": "category",
            "estado_cliente": "category",
            "valor": "float64",
        },
    )

    # Imputa a mediana de 'valor' por estado (vetorizado, sem loops)
    df["valor"] = df["valor"].fillna(
        df.groupby("estado_cliente", observed=True)["valor"].transform("median")
    )

    # Coluna estática para rastreabilidade do pipeline
    df["plataforma"] = "Mobile"
    return df


# ---------------------------------------------------------------------------
# 2. Engenharia de dados e alinhamento temporal
# ---------------------------------------------------------------------------
def tratar_datas(df: pd.DataFrame) -> pd.DataFrame:
    df["data_transacao"] = pd.to_datetime(df["data_transacao"]).astype("datetime64[ns]")
    df["data_transacao"] = df["data_transacao"].dt.tz_localize(FUSO)

    df["dia_semana"] = df["data_transacao"].dt.day_name()
    df["mes"] = df["data_transacao"].dt.month

    # Mantém somente a primeira ocorrência de duplicatas
    df = df.drop_duplicates(keep="first").reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# 3. Filtros bitwise vetorizados
# ---------------------------------------------------------------------------
def filtrar_setembro_alto_valor(df: pd.DataFrame) -> pd.DataFrame:
    estado_ok = (df["estado_cliente"] == "SP") | (df["estado_cliente"] == "RJ")
    valor_ok = df["valor"] > 5000.0
    mes_ok = df["mes"] == 9
    return df[mes_ok & estado_ok & valor_ok]


# ---------------------------------------------------------------------------
# 4. Cruzamento e agregação
# ---------------------------------------------------------------------------
def adicionar_risco(df: pd.DataFrame) -> pd.DataFrame:
    df["nivel_risco"] = df["id_cliente"].astype(str).map(RISCO_DICT)
    return df


def tabela_dinamica(df: pd.DataFrame) -> pd.DataFrame:
    return pd.pivot_table(
        df,
        values="valor",
        index="mes",
        columns="nivel_risco",
        aggfunc="sum",
        margins=True,
        margins_name="Total",
        observed=True,
    )


# ---------------------------------------------------------------------------
# 5. Outliers por Z-Score (vetorizado)
# ---------------------------------------------------------------------------
def calcular_zscore_por_estado(df: pd.DataFrame) -> pd.Series:
    """Z = (x - média) / desvio-padrão, calculado dentro de cada estado."""
    grupo = df.groupby("estado_cliente", observed=True)["valor"]
    media = grupo.transform("mean")
    desvio = grupo.transform("std")
    return (df["valor"] - media) / desvio.replace(0, np.nan)


def detectar_anomalias(df: pd.DataFrame, limite: float = 2.5) -> pd.DataFrame:
    df["zscore"] = calcular_zscore_por_estado(df)
    return df[df["zscore"] > limite].copy()


# ---------------------------------------------------------------------------
# 6. Visualização (API orientada a objetos)
# ---------------------------------------------------------------------------
def gerar_grafico(df: pd.DataFrame, saida: str = "grafico_transacoes.png") -> None:
    diario = df.set_index("data_transacao")["valor"].resample("D").sum()
    media_movel = diario.rolling(7).mean()

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(diario.index, diario.values, label="Valor total diário", color="#1f77b4", alpha=0.7)
    ax.plot(media_movel.index, media_movel.values, label="Média móvel (7 dias)",
            color="#d62728", linewidth=2.5)

    ax.set_ylim(bottom=0)
    ax.set_title("Valor total de transações por dia e média móvel de 7 dias")
    ax.set_xlabel("Data")
    ax.set_ylabel("Valor total (R$)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(saida, dpi=150)
    plt.close(fig)


# ---------------------------------------------------------------------------
def main() -> None:
    df = carregar_e_limpar(ARQUIVO_TRANSACOES)
    df = tratar_datas(df)
    print(f"Transações após limpeza e remoção de duplicatas: {len(df)}")
    print(df.head(), "\n")

    filtrado = filtrar_setembro_alto_valor(df)
    print(f"Transações de setembro (SP/RJ, valor > 5000): {len(filtrado)}\n")

    df = adicionar_risco(df)
    pivot = tabela_dinamica(df)
    print("Tabela dinâmica (soma do valor por mês x nível de risco):")
    print(pivot.round(2), "\n")

    anomalias = detectar_anomalias(df, limite=2.5)
    print(f"Anomalias (Z > 2.5): {len(anomalias)}")
    print(anomalias.head(), "\n")
    anomalias.to_csv("anomalias.csv", index=False)

    gerar_grafico(df)
    print("Gráfico salvo em 'grafico_transacoes.png'.")


if __name__ == "__main__":
    main()
