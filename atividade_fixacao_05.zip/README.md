# Atividade de Fixação 05 – Análise de dados de transações (Fintech)

Aplicação em Python/Pandas que limpa, transforma e consolida dados de transações financeiras, detecta anomalias e gera um relatório visual.

## Como executar

```bash
pip install -r requirements.txt
python gerar_dados.py          # gera transacoes.csv e cotacoes.csv
python analise_transacoes.py   # executa o pipeline
```

## Saídas

- Resumo no terminal (filtros, tabela dinâmica, anomalias)
- `anomalias.csv`: transações com Z-Score > 2,5
- `grafico_transacoes.png`: valor diário e média móvel de 7 dias

## Etapas implementadas

1. **Ingestão e limpeza**: leitura com `encoding='latin1'`, `dtype` category para colunas categóricas, imputação da mediana de `valor` por estado (`groupby().transform('median')`), coluna `plataforma = 'Mobile'`.
2. **Datas**: conversão para `datetime64[ns]`, `tz_localize('America/Sao_Paulo')`, colunas `dia_semana` e `mes` via `.dt`, remoção de duplicatas (`keep='first'`).
3. **Filtro bitwise**: setembro **&** (SP **|** RJ) **&** valor > 5000, sem loops.
4. **Risco e pivot**: `.map(risco_dict)` e `pivot_table(margins=True)` por mês × nível de risco.
5. **Outliers**: Z-Score vetorizado por estado; anomalias com Z > 2,5 em novo DataFrame.
6. **Gráfico**: API orientada a objetos (`fig, ax = plt.subplots()`), `ax.set_ylim(bottom=0)`, título e legendas.

> Observação: `cotacoes.csv` é gerado pelo script, mas não é usado nos requisitos desta atividade.
